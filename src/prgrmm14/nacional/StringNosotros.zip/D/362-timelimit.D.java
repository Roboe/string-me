/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package projecta;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author usraux
 */
public class D {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
        String linea;
        while(!(linea = br.readLine()).equals("0 0")){
        String[] s = linea.split(" ");
        int numFil = Integer.parseInt(s[0]), fila = Integer.parseInt(s[1]), totales = 0, tirados = 0;
        int aux = numFil;
        for (int i = 1; i <= numFil; i++) {
            totales = totales + (i);
        }
        for (int i = 0, j=1; i <= (aux-fila); i++, j++) {
            tirados = tirados + (j);
        }
        System.out.println(totales - tirados);
        }
    }
}

