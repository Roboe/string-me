/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package projecta;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author usraux
 */
public class I {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String linea;
        while(!(linea = br.readLine()).equals("0 0 0")){
            String[] nums = linea.split(" ");
            int diasT = Integer.parseInt(nums[0]);
            int longP = Integer.parseInt(nums[1]);
            int maxD = Integer.parseInt(nums[2]);
            int diasmax = 0;
            int auxT = diasT;
            
            while (auxT >= longP) {
                diasmax+=maxD;
                auxT-=longP;
            }
            if (auxT > maxD) {
                diasmax+=maxD;
            } else {
                diasmax+=auxT;
            }
            System.out.println(diasmax);
            
            
        }
        
    }
}

